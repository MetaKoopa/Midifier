package main;

public class CustomLaunchException extends Exception {

    public CustomLaunchException(String message) {

        super(message);
    }
}