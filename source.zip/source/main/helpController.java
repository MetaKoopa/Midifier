package main;

        import javafx.application.Application;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.fxml.Initializable;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.control.Tab;
        import javafx.stage.Stage;

        import java.net.URL;
        import java.util.ResourceBundle;

public class helpController implements Initializable{

    @FXML
    private Tab fileTab;

    @FXML
    private Tab pianoTab;

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources) {

    }

}

